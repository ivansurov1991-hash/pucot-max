"""Cloud publishing for the approved PUCOT channel. No third-party packages."""
import base64
import hashlib
import html
import json
import os
from pathlib import Path
import ssl
import struct
import sys
import time
from datetime import datetime, timedelta, timezone
from html.parser import HTMLParser
from urllib.error import HTTPError
from urllib.parse import urlencode, urlsplit
from urllib.request import HTTPRedirectHandler, HTTPSHandler, Request, build_opener, urlopen

ROOT = Path(__file__).resolve().parent
REPO = "ivansurov1991-hash/pucot-max"
CHANNEL = -71261823232607
BOT = "id9103102000_bot"
MAX = "https://platform-api2.max.ru"
MAX_CA_SHA256 = "d26d2d0231b7c39f92cc738512ba54103519e4405d68b5bd703e9788ca8ecf31"
GH = f"https://api.github.com/repos/{REPO}"
MSK = timezone(timedelta(hours=3))
SLOTS = ("09:15","10:10","11:00","12:00","13:00","14:00","15:00","16:00","17:00","19:00")


class Stop(RuntimeError):
    pass


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args):
        return None


def secret(name):
    value = os.environ.get(name, "").strip()
    if not value:
        raise Stop(f"Missing {name}")
    return value


def max_tls():
    pem = (ROOT / "max-root.pem").read_text(encoding="ascii")
    der = ssl.PEM_cert_to_DER_cert(pem)
    if hashlib.sha256(der).hexdigest() != MAX_CA_SHA256:
        raise Stop("Не совпадает отпечаток официального корневого сертификата MAX.")
    context = ssl.create_default_context()
    context.load_verify_locations(cadata=ssl.DER_cert_to_PEM_cert(der))
    return context


def call(url, token, *, method="GET", data=None, content_type="application/json"):
    if isinstance(data, dict):
        data = json.dumps(data).encode()
    headers = {"Authorization": token, "Accept": "application/json",
               "Content-Type": content_type, "User-Agent": "PUCOT-MAX-publisher"}
    request = Request(url, method=method, headers=headers, data=data)
    handlers = [NoRedirect]
    if urlsplit(url).netloc == "platform-api2.max.ru" and urlsplit(url).scheme == "https":
        handlers.append(HTTPSHandler(context=max_tls()))
    with build_opener(*handlers).open(request, timeout=40) as response:
        return json.load(response)


def verified_access(token):
    bot = call(f"{MAX}/me", token)
    if (bot.get("username") or "").lower().lstrip("@") != BOT or not bot.get("is_bot"):
        raise Stop("Токен принадлежит другому боту или имя бота не подтверждено.")
    member = call(f"{MAX}/chats/{CHANNEL}/members/me", token)
    if "write" not in (member.get("permissions") or []):
        raise Stop("MAX не подтвердил право публикации в указанном канале.")


def slot_key(started, now, cron):
    day = started.astimezone(MSK)
    if cron:
        minute, hour, *_ = cron.split()
        label = f"{(int(hour) + 3) % 24:02}:{int(minute):02}"
        if label not in SLOTS:
            raise Stop("Неизвестное время расписания.")
    else:
        available = [s for s in SLOTS if s <= day.strftime("%H:%M")]
        if not available:
            raise Stop("Сегодня ещё не наступил первый выпуск.")
        label = available[-1]
    h, m = map(int, label.split(":"))
    planned = day.replace(hour=h, minute=m, second=0, microsecond=0)
    if not timedelta(0) <= now - planned < timedelta(minutes=50):
        raise Stop("Окно выпуска прошло или ещё не наступило.")
    return f"{day.date()}_{h:02}{m:02}"


def load_card(key):
    path = ROOT / "ready" / (key + ".json")
    if not path.is_file():
        raise Stop(f"Для {key} нет готового материала с утверждённой фотографией.")
    card = json.loads(path.read_text(encoding="utf-8"))
    image = (ROOT / card["image"]).resolve()
    if not image.is_relative_to(ROOT / "media"):
        raise Stop("Изображение должно находиться в media.")
    data = image.read_bytes()
    if hashlib.sha256(data).hexdigest() != card["sha256"]:
        raise Stop("Фотография отличается от утверждённого файла с логотипом.")
    if data[:16] != b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR":
        raise Stop("Требуется оригинальный PNG.")
    w, h = struct.unpack(">II", data[16:24])
    if max(w,h) < 1536 or min(w,h) < 900:
        raise Stop("Размер фотографии слишком мал.")
    return card, data


class Headings(HTMLParser):
    def __init__(self):
        super().__init__()
        self.active = False
        self.pieces = []

    def handle_starttag(self, tag, attrs):
        if tag in {"h1", "title"}:
            self.active = True

    def handle_endtag(self, tag):
        if tag in {"h1", "title"}:
            self.active = False

    def handle_data(self, data):
        if self.active:
            self.pieces.append(data)


def course_is_live(course):
    if not course:
        return False
    parsed = urlsplit(course["url"])
    if parsed.scheme != "https" or parsed.hostname != "putsot.ru" or not parsed.path.startswith("/catalog/"):
        raise Stop("Не удалось подтвердить адрес программы.")
    try:
        with urlopen(Request(course["url"], headers={"User-Agent":"PUCOT course link check"}),timeout=10) as response:
            end = urlsplit(response.geturl())
            if end.scheme != "https" or end.hostname not in {"putsot.ru","www.putsot.ru"} or end.path.rstrip("/") != parsed.path.rstrip("/"):
                return False
            headings = Headings()
            headings.feed(response.read(800_000).decode("utf-8",errors="replace"))
            return course["match"].casefold() in " ".join(headings.pieces).casefold()
    except OSError:
        return False


def caption(card, course_live):
    paragraphs = [f"<b>{html.escape(card['title'])}</b>", *map(html.escape, card["paragraphs"])]
    links = list(card["links"])
    if course_live:
        c = card["course"]
        paragraphs.append(html.escape(card["course_paragraph"]))
        links.insert(0, [c["label"], c["url"]])
    else:
        links = [(label, url) for label, url in links if url != "https://putsot.ru/"]
    anchors = [f'<a href="{html.escape(url,quote=True)}">{html.escape(label)}</a>' for label,url in links]
    paragraphs.append("\n".join(" · ".join(anchors[i:i+3]) for i in range(0,len(anchors),3)))
    text = "\n\n".join(paragraphs)
    if len(text) > 4000:
        raise Stop("Превышен лимит MAX в 4000 символов.")
    return text, {url for _,url in links if url.startswith("https://")}


def upload_photo(token, data):
    dest = call(f"{MAX}/uploads?type=image", token, method="POST")["url"]
    url = urlsplit(dest)
    if url.scheme != "https" or url.hostname != "iu.oneme.ru" or url.username or url.port:
        raise Stop("MAX вернул незнакомый адрес загрузки фотографии.")
    boundary = "PUCOT" + os.urandom(16).hex()
    header = (f'--{boundary}\r\nContent-Disposition: form-data; name="data"; filename="image.png"\r\n'
              'Content-Type: image/png\r\n\r\n').encode()
    body = header + data + f"\r\n--{boundary}--\r\n".encode()
    result = call(dest, token, method="POST", data=body, content_type=f"multipart/form-data; boundary={boundary}")
    entries = list(result["photos"].values())
    if len(entries) != 1 or not entries[0].get("token"):
        raise Stop("MAX не подтвердил загрузку одной фотографии.")
    return {"type":"image", "payload":{"token":entries[0]["token"]}}


def check_message(message, card, expected_links):
    body = message.get("body") or {}
    received = [a.get("type") for a in (body.get("attachments") or [])]
    urls = {m.get("url") for m in (body.get("markup") or []) if m.get("type")=="link"}
    if (message.get("recipient",{}).get("chat_id") != CHANNEL or not body.get("mid") or
        (body.get("text") or "").split("\n",1)[0] != card["title"] or
        received != ["image"] or not expected_links.issubset(urls)):
        raise Stop("Запись требует сверки по каналу, фото или ссылкам. Повторная отправка заблокирована.")
    return body["mid"]


def receipt(url, auth):
    try:
        return call(url + "?ref=main",auth)
    except HTTPError as error:
        if error.code == 404:
            return None
        raise


def save_receipt(url, auth, key, record, previous=None):
    b64 = base64.b64encode(json.dumps(record,ensure_ascii=False).encode()).decode()
    body = {"message": f"MAX {key} {record['status']}", "content": b64, "branch":"main"}
    if previous:
        body["sha"] = previous
    return call(url, auth, method="PUT", data=body)["content"]["sha"]


def write_with_photo(token, body, method, url):
    for delay in (0,2,4,8,16,25):
        if delay:
            time.sleep(delay)
        try:
            return call(url,token,method=method,data=body)
        except HTTPError as error:
            try:
                code = json.loads(error.read()).get("code")
            except ValueError:
                code = None
            if error.code not in (400, 409, 422, 503) or code != "attachment.not.ready":
                raise
    raise Stop("MAX сообщил, что фотография ещё обрабатывается. Проверьте журнал заявки.")


def post_with_photo(token, body):
    url = f"{MAX}/messages?chat_id={CHANNEL}&disable_link_preview=true"
    return write_with_photo(token,body,"POST",url)["message"]


def read_message(token, mid):
    query = urlencode({"message_ids":mid})
    found = call(f"{MAX}/messages?{query}",token)["messages"]
    if len(found) != 1 or found[0].get("body",{}).get("mid") != mid:
        raise Stop("MAX принял запрос, но прочитать запись по её ID пока не удалось.")
    return found[0]


def repair_warehouse(token):
    card, data = load_card("warehouse")
    target = "https://max.ru/c/-71261823232607/AaGdHC3-eIw"
    history = call(f"{MAX}/messages?chat_id={CHANNEL}&count=100",token)["messages"]
    matches = [m for m in history if m.get("url","").rstrip("/") == target]
    if len(matches) != 1 or matches[0].get("recipient",{}).get("chat_id") != CHANNEL:
        raise Stop("Исходная запись не найдена по ссылке в нужном канале. Исправление остановлено.")
    old = matches[0]
    heading = (old["body"].get("text") or "").strip().split("\n",1)[0]
    if heading not in (card["title"],"Склад запускает конвейер. Кто примет первую смену?"):
        raise Stop("У исходной записи изменился заголовок. Проверьте её до редактирования.")
    text, links = caption(card,course_is_live(card["course"]))
    if heading == card["title"]:
        try:
            check_message(old,card,links)
            print("Оформление записи уже проверено:",target)
            return
        except Stop:
            pass
    mid = old["body"]["mid"]
    url = MAX + "/messages?" + urlencode({"message_id":mid})
    photo = upload_photo(token,data)
    reply = write_with_photo(token,{"text":text,"format":"html","attachments":[photo]},"PUT",url)
    if reply.get("success") is not True:
        raise Stop("MAX не подтвердил редактирование исходного поста.")
    updated = read_message(token,mid)
    check_message(updated,card,links)
    if updated.get("url","").rstrip("/") != target:
        raise Stop("После изменения не удалось подтвердить прежнюю ссылку.")
    print("Исправлена прежняя запись:",target)


def publish(key, token, auth):
    card, data = load_card(key)
    target = f"{GH}/contents/delivery/{key}.json"
    previous = receipt(target, auth)
    record = json.loads(base64.b64decode(previous["content"])) if previous else None
    if record and record["status"] == "sent":
        print("Уже опубликовано:", record["mid"])
        return
    text, links = caption(card, course_is_live(card.get("course"))) if record is None else (None,set(record["links"]))
    history = call(f"{MAX}/messages?chat_id={CHANNEL}&count=100",token)["messages"]
    # Also covers a successful post followed by a timeout writing its receipt.
    matches = [m for m in history if (m.get("body",{}).get("text") or "").split("\n",1)[0] == card["title"]]
    if len(matches) > 1:
        raise Stop("Несколько совпадений по заголовку. Нужна сверка, отправка остановлена.")
    if matches:
        message = matches[0]
        sha = previous["sha"] if previous else None
    elif record:
        raise Stop("Предыдущая доставка осталась неподтверждённой. Повторная отправка заблокирована.")
    else:
        photo = upload_photo(token, data)
        # Atomic creation must succeed before sending. A racing run cannot create the same file.
        sha = save_receipt(target,auth,key,{"status":"pending","links":sorted(links)})
        message = post_with_photo(token,{"text":text,"format":"html","attachments":[photo]})
        mid = message["body"]["mid"]
        message = read_message(token,mid)
    mid = check_message(message,card,links)
    save_receipt(target,auth,key,{"status":"sent","mid":mid,"url":message.get("url")},sha)
    print("Опубликовано:", message.get("url") or mid)


def main():
    mode = sys.argv[1]
    if mode == "preview":
        card,_ = load_card(sys.argv[2])
        for live in (False,True) if card.get("course") else (False,):
            text,links = caption(card,live)
            print(card["title"], "|", len(text), "символов |",len(links),"HTTPS-ссылок")
        return
    if os.environ.get("GITHUB_REPOSITORY") != REPO or os.environ.get("GITHUB_REF") != "refs/heads/main":
        raise Stop("Запуск разрешён только в основной ветке репозитория ПУЦОТ.")
    token = secret("MAX_BOT_TOKEN")
    verified_access(token)
    if mode == "check":
        print("MAX подтвердил имя бота и право публикации.")
        return
    if mode == "repair":
        repair_warehouse(token)
        return
    if mode != "due":
        raise Stop("Неизвестная команда.")
    auth = "Bearer " + secret("GITHUB_TOKEN")
    run_id = int(os.environ["GITHUB_RUN_ID"])
    run = call(f"{GH}/actions/runs/{run_id}",auth)
    started = datetime.fromisoformat(run["created_at"].replace("Z","+00:00"))
    key = slot_key(started,datetime.now(MSK),os.environ.get("POST_CRON",""))
    publish(key,token,auth)


if __name__ == "__main__":
    try:
        main()
    except HTTPError as error:
        sys.exit(f"HTTP {error.code} ({urlsplit(error.url).hostname}). Проверьте статус выпуска перед повтором.")
    except Stop as error:
        sys.exit(str(error))
    except (OSError, KeyError, ValueError) as error:
        sys.exit(f"Операция не подтверждена ({type(error).__name__}). Проверьте статус выпуска.")
